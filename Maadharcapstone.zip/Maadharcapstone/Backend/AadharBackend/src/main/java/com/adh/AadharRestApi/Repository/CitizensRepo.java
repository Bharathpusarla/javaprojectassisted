package com.adh.AadharRestApi.Repository;

import org.springframework.data.repository.CrudRepository;

import com.adh.AadharRestApi.Entity.Citizens;

public interface CitizensRepo extends CrudRepository<Citizens, Integer>{

}
