package com.samples.Demo;

public class Car implements Vehicle {
	public void drive() {
		System.out.println("it's a car");
	}

}
