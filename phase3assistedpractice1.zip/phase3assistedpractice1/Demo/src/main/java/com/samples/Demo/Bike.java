package com.samples.Demo;

public class Bike implements Vehicle{
	public void drive() {
		System.out.println("It's a Bike");
	}

}
