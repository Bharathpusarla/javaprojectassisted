package com.samples.Demo;

public interface Vehicle {
	void drive();

}
