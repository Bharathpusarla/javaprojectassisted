package com.samples.ElData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElDataApplication.class, args);
	}

}
