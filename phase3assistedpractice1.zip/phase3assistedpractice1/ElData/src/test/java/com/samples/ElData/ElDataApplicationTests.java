package com.samples.ElData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
