function greet(name) {
  console.log('Hello ' + name);
}

// Hoisting
console.log(x);
greet('William');

var x = 20;
